Below 3 *.csv files are tables custom-built using the TableBuilder application in 
Australia Bureau of Statistics (ABS) website: https://www.abs.gov.au/

RELIGIONsxBCpoa.csv (from Census 2016)
table columns: PostcodeCombo, birthCountry, Sex, Religion, count

WIDX5bc245POA2021.csv (from Census 2021)
table columns: postcodeCombo, birthCountry, wealthGroups by weekly incomes, count

WIDXbcPOA2016.csv ( from Census 2016)
table columns: postcodeCombo, birthCountry, wealthGroups by weekly incomes, count

Becasue they are big tables, normal spreadsheet software may have problem to open them. 
Using wordpad to view the *.csv

You could register an account with ABS and could get access to TableBuilder to start build your own tables 
for your specifc data queries. Above 3 are starting points.

*.ipynb
Jupyter Notebook with pyspark libraries

diverse2016.ipynb
data query that find the Australian postcode that has the most diverse ethnic groups mix from Census 2016
input file: WIDXbcPOA2016.csv

diverse2021.ipynb
data query that find the Australian postcode that has the most diverse ethnic groups mix from Census 2021
input file: WIDX5bc245POA2021.csv 

religionsxPOA.ipynb
data query that bar-chart female/male composition in three top regilion affilIations in Census 2016
input file: RELIGIONsxBCpoa.csv

wealth2016.ipynb
data query that gives which groups (by birthCountry) that are well represented in the top half tax income groups in 
Census 2016.input file: WIDXbcPOA2016.csv 

wealth2021.ipynb
data query that gives which groups (by birthCountry) that are well represented in the top half tax income groups in 
Census 2021.input file: WIDX5bc245POA2021.csv 

